package com.blockark.app;
interface IBackupService {
    void destroy() = 16777114;
    String run(String cmd) = 1;
}
