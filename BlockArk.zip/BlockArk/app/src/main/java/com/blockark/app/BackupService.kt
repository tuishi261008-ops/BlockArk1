package com.blockark.app

// Shizuku経由でshell権限(uid 2000)で動くサービス
class BackupService : IBackupService.Stub() {
    override fun destroy() { System.exit(0) }
    override fun run(cmd: String): String {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out
    }
}
