package com.blockark.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume

const val KEEP = 48          // ワールドごとに保持するバックアップ数
const val INTERVAL_MIN = 5L  // バックアップ間隔(分)
const val SRC = "/sdcard/Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"
const val DST = "/sdcard/MinecraftBackup"

data class World(val id: String, val name: String)

fun shizukuReady() = Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED

/** Shizukuのshellサービスに接続してblockを実行（IOスレッドから呼ぶこと） */
suspend fun <T> withShizuku(ctx: Context, block: (IBackupService) -> T): T? {
    if (!shizukuReady()) return null
    val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, BackupService::class.java.name))
        .daemon(false).processNameSuffix("backup").version(1)
    val conn = object : ServiceConnection {
        var cb: ((IBackupService) -> Unit)? = null
        override fun onServiceConnected(n: ComponentName, b: IBinder) { cb?.invoke(IBackupService.Stub.asInterface(b)) }
        override fun onServiceDisconnected(n: ComponentName) {}
    }
    val svc = withTimeoutOrNull(10_000) {
        suspendCancellableCoroutine<IBackupService> { cont ->
            conn.cb = { if (cont.isActive) cont.resume(it) }
            Shizuku.bindUserService(args, conn)
        }
    }
    if (svc == null) { Shizuku.unbindUserService(args, conn, true); return null }
    return try { block(svc) } finally { Shizuku.unbindUserService(args, conn, true) }
}

fun listWorlds(svc: IBackupService): List<World> {
    val cmd = "cd \"$SRC\" 2>/dev/null && for d in */; do d=\${d%/}; echo \"\$d|\$(cat \"\$d/levelname.txt\" 2>/dev/null)\"; done"
    return svc.run(cmd).lines().filter { it.contains("|") }.map {
        val (id, name) = it.split("|", limit = 2)
        World(id, name.ifBlank { id })
    }
}

private fun safe(s: String) = s.replace(Regex("[/\\\\\"'`$\\n\\r]"), "_")

/** 1ワールドをバックアップ。前回から変更がなければSKIP */
fun backupWorld(svc: IBackupService, w: World): String {
    val id = safe(w.id)
    val dir = "$DST/${safe(w.name)}_${id.take(6)}"
    val cmd = listOf(
        "SRC=\"$SRC\"; D=\"$dir\"; ID=\"$id\"",
        "[ -d \"\$SRC/\$ID\" ] || { echo ERR_NO_WORLD; exit 1; }",
        "mkdir -p \"\$D\"",
        "LAST=\$(ls -1t \"\$D\"/*.tar.gz 2>/dev/null | head -n 1)",
        "if [ -n \"\$LAST\" ] && [ -z \"\$(find \"\$SRC/\$ID\" -newer \"\$LAST\" 2>/dev/null | head -n 1)\" ]; then echo SKIP; exit 0; fi",
        "tar -czf \"\$D/\$(date +%Y%m%d_%H%M%S).tar.gz\" -C \"\$SRC\" \"\$ID\" || { echo ERR_TAR; exit 1; }",
        "ls -1t \"\$D\"/*.tar.gz | tail -n +${KEEP + 1} | while read f; do rm \"\$f\"; done",
        "echo OK"
    ).joinToString("\n")
    return svc.run(cmd).trim().lines().lastOrNull() ?: "ERR"
}
