package com.blockark.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val scope = MainScope()
    private val prefs by lazy { getSharedPreferences("mc", 0) }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r ->
        runOnUiThread {
            status.text = if (r == PackageManager.PERMISSION_GRANTED) "権限を許可しました" else "権限が拒否されました"
        }
    }

    private fun requestShizuku() {
        try {
            when {
                !Shizuku.pingBinder() -> status.text = "Shizukuが起動していません。Shizukuアプリで起動してください"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> status.text = "権限は許可済みです"
                Shizuku.shouldShowRequestPermissionRationale() ->
                    status.text = "拒否されています。ShizukuアプリでBlockArkを許可してください"
                else -> Shizuku.requestPermission(0)
            }
        } catch (e: Throwable) { status.text = "エラー: ${e.message}" }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(permListener)
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Shizuku.addRequestPermissionResultListener(permListener)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        status = TextView(this).apply { textSize = 15f }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40)
            addView(status)
            addView(btn("1. Shizuku権限を許可") { requestShizuku() })
            addView(btn("2. ワールド一覧を読み込む") { loadWorlds() })
            addView(list)
            addView(btn("3. 自動バックアップ開始（${INTERVAL_MIN}分毎）") {
                startForegroundService(Intent(this@MainActivity, BackupForegroundService::class.java))
                status.text = "開始しました。通知で状況を確認できます"
            })
            addView(btn("停止") {
                stopService(Intent(this@MainActivity, BackupForegroundService::class.java))
                status.text = "停止しました"
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
        status.text = if (Shizuku.pingBinder()) "Shizuku: 接続OK" else "Shizukuを起動してください"
    }

    private fun loadWorlds() = scope.launch {
        status.text = "読み込み中…"
        val ws = withContext(Dispatchers.IO) { withShizuku(this@MainActivity) { listWorlds(it) } }
        if (ws == null) { status.text = "Shizukuが未起動、または権限がありません"; return@launch }
        status.text = "バックアップするワールドを選択（${ws.size}個）"
        list.removeAllViews()
        val sel = prefs.getStringSet("sel", emptySet())!!.toMutableSet()
        ws.forEach { w ->
            list.addView(CheckBox(this@MainActivity).apply {
                text = w.name; isChecked = w.id in sel
                setOnCheckedChangeListener { _, c ->
                    if (c) sel.add(w.id) else sel.remove(w.id)
                    prefs.edit().putStringSet("sel", sel.toSet()).apply()
                }
            })
        }
    }
}
