package com.blockark.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class BackupForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String) = Notification.Builder(this, "bk")
        .setContentTitle("BlockArk").setContentText(text).setOngoing(true)
        .setSmallIcon(android.R.drawable.stat_sys_download_done).build()

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bk", "Backup", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif("開始中…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.coroutineContext.cancelChildren()
        scope.launch {
            while (isActive) {
                val sel = getSharedPreferences("mc", 0).getStringSet("sel", emptySet())!!.toSet()
                val res = withShizuku(this@BackupForegroundService) { svc ->
                    listWorlds(svc).filter { it.id in sel }.map { "${it.name}:${backupWorld(svc, it)}" }
                }
                val t = SimpleDateFormat("HH:mm", Locale.JAPAN).format(Date())
                val msg = when {
                    res == null -> "$t Shizuku未接続（再試行します）"
                    res.isEmpty() -> "$t 対象ワールド未選択"
                    else -> "$t " + res.joinToString(" / ")
                }
                nm.notify(1, notif(msg))
                delay(INTERVAL_MIN * 60_000L)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { scope.cancel() }
}
