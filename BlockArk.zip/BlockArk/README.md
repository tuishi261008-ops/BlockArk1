# BlockArk (Minecraft Bedrock backup / Android 14 + Shizuku)
- GitHubにpush → Actions → Build APK → Artifacts の app-debug をDL
- 保存先: 内部ストレージ/MinecraftBackup/<ワールド名>_xxxxxx/日時.tar.gz
- 5分毎に変更があったワールドだけ保存、各48件保持（KEEP / INTERVAL_MIN は BackupCore.kt）
- 復元: tar.gz を minecraftWorlds に展開
